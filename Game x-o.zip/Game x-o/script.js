"use strict";

let x = 'X';
let o = 'O';
let arr = [];
let count = 0;
let player1;
let player2;
let point1 = 0;
let point2 = 0;

start();

function start() {
    player1 = prompt('Oyuncu 1', 'X');
    player2 = prompt('Oyuncu 2', 'O');

    Arr();
    

}

table();
function table() {
    let tbl = document.getElementById('tbl');
    let tr = '';

    for (let i = 0; i < 3; i++) {
        tr += '<tr>';
        for (let j = 0; j < 3; j++) {
            // tr += `<td onclick="klik(${i},${j})">${arr[i][j] ?? ' '}</td>`;
            tr += `<td onclick="klik(${i},${j})">${arr[i][j] === undefined ? ` ` : arr[i][j]}</td>`;
        }
        tr += '</tr>';
    }
    tbl.innerHTML = tr;
}

function Arr() {
    for (let i = 0; i < 3; i++) {
        arr[i] = [];
    }
}

function klik(i, j) {
    if (arr[i][j] === undefined) {
        if (count % 2 === 0) {
            arr[i][j] = o;
        } else {
            arr[i][j] = x;
        }
        count++;
        table();

        setTimeout(() => {
            chek();
        }, 200);
    }
}

function chek() {
    for (let i = 0; i < 3; i++) {
        if (arr[i][0] !== undefined && arr[i][0] === arr[i][1] && arr[i][1] === arr[i][2]) {
            if (arr[i][0] === player1) {
                point1 += 10;
                alert(player1 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            } else {
                point2 += 10;
                alert(player2 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }

            return;
        } else if (arr[0][i] !== undefined && arr[0][i] === arr[1][i] && arr[1][i] === arr[2][i]) {
            if (arr[0][i] === player1) {
                point1 += 10;
                alert(player1 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }
            else {
                point2 += 10;
                alert(player2 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }
            return;
        }
        else if (arr[0][0] !== undefined && arr[0][0] === arr[1][1] && arr[1][1] === arr[2][2]) {
            if (arr[0][0] === player1) {
                point1 += 10;
                alert(player1 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }
            else {
                point2 += 10;
                alert(player2 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }
            return
        }
        else if (arr[0][2] !== undefined && arr[0][2] === arr[1][1] && arr[1][1] === arr[2][0]) {
            if (arr[0][2] === player1) {
                point1 += 10;
                alert(player1 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }

            else {
                point2 += 10;
                alert(player2 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + 'xali: ' + point2);
                resetGame()
            }
            return;

        }
        else if (arr[0][1] !== undefined && arr[0][1] === arr[1][1] && arr[1][1] === arr[2][1]) {
            if (arr[0][1] === player1) {
                point1 += 10;
                alert(player1 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }
            else {
                point2 += 10;
                alert(player2 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + 'xali: ' + point2);
                resetGame()
            }
            return;
        }
        else if (arr[0][2] !== undefined && arr[0][2] === arr[1][2] && arr[1][2] === arr[2][2]) {
            if (arr[0][2] === player1) {
                point1 += 10;
                alert(player1 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }
            else {
                point2 += 10;
                alert(player2 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + 'xali: ' + point2);
                resetGame()
            }
            return;
        }
        else if (arr[1][0] !== undefined && arr[1][0] === arr[1][1] && arr[1][1] === arr[1][2]) {
            if (arr[1][0] === player1) {
                point1 += 10;
                alert(player1 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }
            else {
                point2 += 10;
                alert(player2 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + 'xali: ' + point2);
                resetGame()
            }
            return;
        }
        else if (arr[2][0] !== undefined && arr[2][0] === arr[2][1] && arr[2][1] === arr[2][2]) {
            if (arr[2][0] === player1) {
                point1 += 10;
                alert(player1 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + ' xali: ' + point2);
                resetGame()
            }
            else {
                point2 += 10;
                alert(player2 + ' Qazandi! ' + player1 + ' xali: ' + point1 + ', ' + player2 + 'xali: ' + point2);
                resetGame()
            }
            return;
        }
        else {
            if (count === 9) {
                confirm('Oyun berabere bitdi! Tekrar oynayirsinizmi?');
                resetGame()
                return
            }
        }
        return;

    }
}
function resetGame() {
    point1 = 0;
    point2 = 0;
    count = 0;
    Arr();
    table();
}

